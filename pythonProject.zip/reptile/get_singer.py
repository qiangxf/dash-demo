import pandas as pd
from requests_html import HTMLSession


def get_msg(page):
    session = HTMLSession()
    url = "http://y.saoju.net/szzj/?page=" + str(page)
    r = session.get(url)

    # 根据标签查找关键字
    table = r.html.find("table tr", first=False)

    # 歌手名称
    song_name = []
    # 专辑名称
    singer_name = []
    # 发行时间
    product_time = []
    # 专辑累计销量
    total_price = []

    for item in table:
        temp = item.text.replace("'", '').replace('-', '').replace('  ', ' ').split('\n')
        if len(temp) <= 7:
            continue

        # 处理歌手名称和专辑名称
        temp2 = temp[0].split('》')
        song_name.append(temp2[0] + "》")
        singer_name.append(temp2[1])

        # 处理专辑发行时间
        temp3 = temp[1].split(" ")
        product_time.append(temp3[0])

        # 销售总金额
        total_price.append(temp[2] + "元")

    data = pd.DataFrame(columns=['专辑名称', '歌手名称', '发行时间', '专辑累计销量'])
    data['歌手名称'] = singer_name
    data['专辑名称'] = song_name
    data['发行时间'] = product_time
    data['专辑累计销量'] = total_price

    return data


if __name__ == "__main__":
    concat_data = []
    for i in range(10):
        print(f"begin to deal page {i}")
        concat_data.append(get_msg(i))

    concat_data = pd.concat(concat_data)
    concat_data.reset_index(inplace=True)
    concat_data.to_csv(r"C:\Users\qxf101\PycharmProjects\pythonProject\reptile\result.csv", encoding='utf-8',
                       index=False)
