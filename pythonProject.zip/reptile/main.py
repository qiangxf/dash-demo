from flask import Flask
import requests
import json

app = Flask(__name__)


def get_news():
    url = "https://news.cctv.com/2019/07/gaiban/cmsdatainterface/page/news_1.jsonp?cb=news"
    header = {'User-Agent': 'Mozilla/5.0'}

    r = requests.get(url, headers=header)
    r.encoding = 'utf-8'
    # 响应的内容
    result = r.text

    parse_result = json.loads(result[5:][:-1])

    news = parse_result.get('data').get('list')

    data = []
    for new in news:
        data.append(new.get('title'))

    output = dict()
    output.update({
        "title": data
    })

    return output


@app.route("/news/out")
def hello():
    data = get_news()
    return data


if __name__ == "__main__":
    app.config['JSON_AS_ASCII'] = False
    app.run(host='0.0.0.0', debug=False, port=33098)
