# -*- coding: utf-8 -*-
import os

import dash
import dash_core_components as dcc
import dash_html_components as html
import flask
import pandas as pd
import plotly.graph_objs as go
from dash.dependencies import Input, Output

server = flask.Flask(__name__)

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
app = dash.Dash(__name__, external_stylesheets=external_stylesheets)
server = app.server

app.layout = html.Div(children=[

    html.Button('上一页', id='prev', n_clicks=0, value=0),
    html.Button('下一页', id='next', n_clicks=0, value=0),
    html.H1(id='name'),
    html.H1(id='pre_num', style='display:none'),
    html.H1(id='next_num', style='display:none'),

    dcc.Graph(
        id='example-graph-1'
    ),
    dcc.Graph(
        id='example-graph-2'
    ),
    dcc.Graph(
        id='example-graph-3'
    ),
])

global current_page
current_page = 1


@app.callback(
    [
        Output(component_id='example-graph-1', component_property='figure'),
        Output(component_id='example-graph-2', component_property='figure'),
        Output(component_id='example-graph-3', component_property='figure'),
        Output(component_id='name', component_property='children'),
    ],
    [Input('pre_num', 'children'), Input('next_num', 'children')]
)
def show_page(next_val, pre_val):
    global current_page
    data = pd.read_csv(os.path.join(r"C:\Users\qxf101\PycharmProjects\pythonProject\csv", str(current_page) + ".csv"))
    name = data['name'].unique()[0]
    x1 = data['x1']
    x2 = data['x2']
    x3 = data['x3']

    y1 = data['y1']
    y2 = data['y2']
    y3 = data['y3']

    figure1 = go.Figure(data=[go.Scatter(x=x1, y=y1)], layout=go.Layout(title='x1'))
    figure2 = go.Figure(data=[go.Scatter(x=x2, y=y2)], layout=go.Layout(title='x2'))
    figure3 = go.Figure(data=[go.Scatter(x=x3, y=y3)], layout=go.Layout(title='x3'))

    return figure1, figure2, figure3, name


@app.callback(
    Output(component_id='pre_num', component_property='children'),
    [Input('prev', 'n_clicks')]
)
def pre_click(pre_val):
    global current_page
    if current_page == 1:
        current_page = 3
    else:
        current_page -= 1

    return current_page


@app.callback(
    Output(component_id='next_num', component_property='children'),
    [Input('next', 'n_clicks')]
)
def pre_click(next_val):
    global current_page

    if current_page == 3:
        current_page = 1
    else:
        current_page += 1

    return current_page


if __name__ == '__main__':
    app.run_server(debug=False)
